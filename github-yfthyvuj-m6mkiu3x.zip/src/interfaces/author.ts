export type Author = {
  name: string;
  picture: string;
};
