export const EXAMPLE_PATH = "personal-portfolio";
export const CMS_NAME = "Markdown";
export const SITE_NAME = "My Creative Portfolio";
export const HOME_OG_IMAGE_URL =
  "https://og-image.vercel.app/Personal%20Portfolio%20%26%20Blog.png?theme=light&md=1&fontSize=100px&images=https%3A%2F%2Fassets.vercel.com%2Fimage%2Fupload%2Ffront%2Fassets%2Fdesign%2Fnextjs-black-logo.svg";